/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package methods;

/**
 *
 * @author 100005978.joan23
 */
public class Storage {
    private String materia;
    private double notamedia;
    private String user;

    public Storage() {
    }

    public Storage(String user, double notamedia, String materia) {
        this.materia = user;
        this.notamedia = notamedia;
        this.user = materia;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public double getNotamedia() {
        return notamedia;
    }

    public void setNotamedia(double notamedia) {
        this.notamedia = notamedia;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    
    
}
